import 'package:flutter/material.dart';
import 'package:skeleton_code/app.dart';

/// This file starts the app.
Future<void> main() async {
  runApp(App());
}
